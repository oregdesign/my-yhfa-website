# my-yhfa-website
Starter Next.js (App Router) + Tailwind + Sanity project for Yayasan Hasanah Fathimiyah.

## How to use
1. Install dependencies: `npm install`
2. Configure environment variables in `.env.local`
3. Run dev: `npm run dev`

This zip contains a minimal working project scaffold with example pages and Sanity schemas.
