export default function About() {
  return (
    <div className="container py-12">
      <h1 className="text-3xl font-bold mb-4">Tentang Yayasan</h1>
      <p>Yayasan Hasanah Fathimiyah berfokus pada pendidikan Islam modern, karakter, dan pengembangan komunitas di Cikarang Barat.</p>
    </div>
  );
}
