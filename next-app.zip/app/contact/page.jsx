export default function Contact() {
  return (
    <div className="container py-12">
      <h1 className="text-3xl font-bold mb-4">Hubungi Kami</h1>
      <p>Alamat: Jl. Ki Asmawi Raya, Kali Jaya, Cikarang Barat</p>
      <p>WhatsApp: +62 813-1706-9693</p>
    </div>
  );
}
