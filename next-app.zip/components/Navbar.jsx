"use client";

import { useState } from "react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="bg-white/90 backdrop-blur-sm sticky top-0 z-40 border-b">
      <div className="container flex items-center justify-between py-1">

        {/* LEFT — Logo */}
        <div className="flex items-center gap-1">
          <div className="rounded-full bg-primary-500 p-2">
            <img
              src="/yihfa_logo.png"
              alt="logo"
              className="h-[50px] w-[50px] rounded-full object-cover"
            />
          </div>
          <div>
            <div className="font-green font-bold leading-tight">
              Yayasan Islam Hasanah Fathimiyah
            </div>
            <div className="text-xs text-gray-500">
              Cikarang Barat, Bekasi
            </div>
          </div>
        </div>

        {/* RIGHT — Desktop Menu */}
        <nav className="hidden md:flex items-center gap-6 text-sm text-gray-700">
          <a href="#about" className="hover:text-primary">Tentang</a>
          <a href="#programs" className="hover:text-primary">Program</a>
          <a href="#gallery" className="hover:text-primary">Galeri</a>
          <a
            href="#contact"
            className="bg-[#0b8d35] text-white px-3 py-2 rounded hover:opacity-95"
          >
            Hubungi
          </a>
        </nav>

        {/* RIGHT — Hamburger Button (Mobile Only) */}
        <button
          className="md:hidden p-2 rounded hover:bg-gray-100"
          onClick={() => setIsOpen(!isOpen)}
        >
          {/* Hamburger Icon */}
          <div className="space-y-1">
            <span className="block w-6 h-0.5 bg-gray-700"></span>
            <span className="block w-6 h-0.5 bg-gray-700"></span>
            <span className="block w-6 h-0.5 bg-gray-700"></span>
          </div>
        </button>
      </div>

      {/* Mobile Menu Dropdown */}
      {isOpen && (
        <div className="md:hidden bg-white shadow-lg border-t px-6 py-4 flex flex-col gap-4 text-gray-700">
          <a href="#about" className="hover:text-primary">Tentang</a>
          <a href="#programs" className="hover:text-primary">Program</a>
          <a href="#gallery" className="hover:text-primary">Galeri</a>
          <a
            href="#contact"
            className="bg-[#0b8d35] text-white px-3 py-2 rounded text-center"
          >
            Hubungi
          </a>
        </div>
      )}
    </header>
  );
}
